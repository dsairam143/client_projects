from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render, redirect
from . import models
from django.core.mail import send_mail
from django.conf import settings

# Create your views here.

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def services(request):
    return render(request, 'enquiry.html')

def enquiry(request):
    return render(request, 'services.html')

def contact(request):
    print(request.method)
    if request.method == 'POST':
        models.Person(name=request.POST['name'],
                      email=request.POST['email'],
                      subject=request.POST['subject'],
                      message=request.POST['message']).save()
        # subject = request.POST['subject']
        # message = request.POST['message']
        # email_from = settings.EMAIL_HOST_USER
        # recipient_list = [request.POST['email'], ]
        # send_mail(subject, message, email_from, recipient_list)

        # return render(request, 'home.html')
        return render(request, 'contact.html', {'response':'Your contact details submitted. We will contact you soon.Thanks'})
    else:
        print('hello')
        return render(request, 'contact.html')