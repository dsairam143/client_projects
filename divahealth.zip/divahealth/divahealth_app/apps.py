from django.apps import AppConfig


class DivahealthAppConfig(AppConfig):
    name = 'divahealth_app'
