    // -------   Mail Send ajax

     $(document).ready(function() {
        var form = $('#myForm'); // contact form
        form.on('submit', function(e) {
//            e.preventDefault(); // prevent default form submit

            $.ajax({
                url: '/fitness/details', // form action url
                type: 'post', // form submit method get/post
                dataType: 'html', // request type html/json/xml
//                data: form.serialize(), // serialize form data
                success: function(data) {
                    alert("Contact.");
                    form.trigger('reset');
                },
                error: function(e) {
                    alert(e);
                }
            });
        });
    });


